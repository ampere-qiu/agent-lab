# Groq classroom starter

Adapted from https://huggingface.co/spaces/agents-course/First_agent_template for the Hugging Face Agents Course. Original copyright notices are retained in source files.

Use the accompanying local course guide for setup. Install requirements.txt in a Python 3.11 virtual environment. Run python app.py and enter your own Groq key when prompted. The key is not included or saved. No Hugging Face login is needed for chat. Model: qwen/qwen3.8-27b via Groq.

The original external image-generation loader is removed. A fresh Mac walkthrough passed live Groq chat, dummy exercises, time lookup, and web search. Windows installation remains untested.

Compatibility update: Qwen with reasoning disabled replaces the GPT-OSS configuration that returned native tool calls. Provider failures are displayed in the chat. The revised connection was tested on Mac; validate your own installation using the course checkpoints.

Start with STUDENT_TASKS.md. This starter deliberately leaves custom-tool implementation and tool registration to you.

Course scope: time and web search are the core tool activities. Custom-tool implementation is optional. Image generation and the HF final quiz/certification are excluded. The local guide provides the lessons.

Search compatibility: the starter now includes tools/web_search.py and uses ddgs==9.16.0 with the DuckDuckGo backend. Register WebSearchTool(max_results=3) during the exercise. The old built-in DuckDuckGoSearchTool is no longer used.

The introductory output budget is 512 tokens per completion. If Groq reports “Request too large”, follow the terminal's named limit; waiting alone will not fix an oversized request. smolagents still installs the legacy duckduckgo-search package as a dependency, but this starter calls ddgs for search.
