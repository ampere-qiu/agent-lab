# Your first-agent tasks

The connection, key prompt, model configuration, prompt file, and chat interface are provided. Start with `python app.py` and verify a simple answer. The two core tools (time and web search) are not registered yet; enabling them is your task. Image generation is removed.

1. Read the supplied timezone function. Add it to `tools`, restart, and confirm its call appears in the trace.
2. Register the search tool. Check both its execution result and one returned link.
Optional extension: design and implement your own tool. Replace the placeholder's signature, documentation, and body; test it directly before registering it. Use one ordinary input and one edge case with known expected results.
Then ask the agent to use your custom tool. Compare its trace and answer against your direct test.

A model claiming to have used a tool is not evidence that it ran: inspect the call and observation. A placeholder raising NotImplementedError is intentional until you implement it.

Do not edit the model connection or interface to complete these tasks. Never put an API key in a source file. The template is adapted from the Hugging Face Agents Course for local Groq use because API and hosting availability differ. Follow the local guide; only the two quick quizzes are retained, with no final quiz or certification requirement.
